import React, { useState } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import initialBooks from './Utils/books';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import Home from './pages/Home';
import Book from './pages/Book';
import AddBook from './pages/AddBook';

export default function App() {
  // Hook useState untuk mengelola array daftar buku (diinisialisasi dari src/Utils/books.js)
  const [books, setBooks] = useState(initialBooks);

  // Fungsi untuk menambahkan buku baru ke dalam state
  const handleAddBook = (newBook) => {
    setBooks((prevBooks) => [newBook, ...prevBooks]);
  };

  // Fungsi opsional untuk menghapus buku dari state
  const handleDeleteBook = (bookId) => {
    if (window.confirm('Apakah Anda yakin ingin menghapus buku ini dari daftar?')) {
      setBooks((prevBooks) => prevBooks.filter((b) => b.id !== bookId));
    }
  };

  return (
    <BrowserRouter>
      <div className="d-flex flex-column min-vh-100">
        {/* Navigasi Utama */}
        <Navbar bookCount={books.length} />

        {/* Konten Halaman Berdasarkan Routing */}
        <main className="flex-grow-1">
          <Routes>
            {/* Halaman Home: Menampilkan daftar buku dengan .map() */}
            <Route
              path="/"
              element={<Home books={books} onDeleteBook={handleDeleteBook} />}
            />

            {/* Halaman Book: Menampilkan katalog buku dengan .map() */}
            <Route
              path="/books"
              element={
                <Book
                  books={books}
                  onAddBook={handleAddBook}
                  onDeleteBook={handleDeleteBook}
                />
              }
            />
            {/* Alias rute /book */}
            <Route
              path="/book"
              element={
                <Book
                  books={books}
                  onAddBook={handleAddBook}
                  onDeleteBook={handleDeleteBook}
                />
              }
            />

            {/* Halaman Tambah Buku: Formulir menggunakan useState */}
            <Route
              path="/add-book"
              element={<AddBook onAddBook={handleAddBook} />}
            />

            {/* Fallback ke halaman Home jika route tidak ditemukan */}
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </main>

        {/* Komponen Footer */}
        <Footer />
      </div>
    </BrowserRouter>
  );
}
