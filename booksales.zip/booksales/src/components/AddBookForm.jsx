import React, { useState } from 'react';

export default function AddBookForm({ onAddBook }) {
  // Penggunaan Hook useState untuk mengelola input formulir
  const [title, setTitle] = useState('');
  const [author, setAuthor] = useState('');
  const [year, setYear] = useState('');
  const [description, setDescription] = useState('');
  const [image, setImage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  // Contoh URL gambar default yang siap pakai
  const sampleImages = [
    'https://images.unsplash.com/photo-1544947950-fa07a98d237f?auto=format&fit=crop&w=600&q=80',
    'https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&w=600&q=80',
    'https://images.unsplash.com/photo-1532012164546-f432f2e3777a?auto=format&fit=crop&w=600&q=80',
    'https://images.unsplash.com/photo-1589829085413-56de8ae18c73?auto=format&fit=crop&w=600&q=80',
  ];

  const handleUseSampleImage = () => {
    const randomImg = sampleImages[Math.floor(Math.random() * sampleImages.length)];
    setImage(randomImg);
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    // Validasi sederhana
    if (!title.trim() || !author.trim()) {
      setErrorMessage('Judul buku dan Penulis wajib diisi!');
      setSuccessMessage('');
      return;
    }

    // Buat objek data buku baru
    const newBook = {
      id: Date.now(), // Generate ID unik berbasis timestamp
      title: title.trim(),
      author: author.trim(),
      year: year ? parseInt(year, 10) : new Date().getFullYear(),
      description: description.trim() || 'Tidak ada deskripsi yang dicantumkan.',
      image: image.trim() || 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=600&q=80'
    };

    // Jalankan callback penambahan buku
    onAddBook(newBook);

    // Reset formulir menggunakan setter useState
    setTitle('');
    setAuthor('');
    setYear('');
    setDescription('');
    setImage('');
    setErrorMessage('');
    setSuccessMessage(`Buku "${newBook.title}" berhasil ditambahkan ke dalam daftar!`);

    // Hilangkan notifikasi sukses setelah 4 detik
    setTimeout(() => {
      setSuccessMessage('');
    }, 4000);
  };

  return (
    <div className="form-card">
      <div className="d-flex align-items-center mb-3">
        <div className="bg-primary text-white rounded p-2 me-3 d-inline-flex">
          <i className="bi bi-journal-plus fs-4"></i>
        </div>
        <div>
          <h4 className="mb-0 fw-bold">Tambah Koleksi Buku Baru</h4>
          <small className="text-muted">Gunakan formulir ini untuk menambahkan data buku ke katalog</small>
        </div>
      </div>

      {successMessage && (
        <div className="alert alert-success alert-dismissible fade show d-flex align-items-center" role="alert">
          <i className="bi bi-check-circle-fill me-2 fs-5"></i>
          <div>{successMessage}</div>
          <button type="button" className="btn-close" onClick={() => setSuccessMessage('')}></button>
        </div>
      )}

      {errorMessage && (
        <div className="alert alert-danger alert-dismissible fade show d-flex align-items-center" role="alert">
          <i className="bi bi-exclamation-triangle-fill me-2 fs-5"></i>
          <div>{errorMessage}</div>
          <button type="button" className="btn-close" onClick={() => setErrorMessage('')}></button>
        </div>
      )}

      <form onSubmit={handleSubmit}>
        <div className="row g-3">
          {/* Judul Buku */}
          <div className="col-md-6">
            <label htmlFor="title" className="form-label fw-semibold">
              Judul Buku <span className="text-danger">*</span>
            </label>
            <div className="input-group">
              <span className="input-group-text"><i className="bi bi-book"></i></span>
              <input
                type="text"
                className="form-control"
                id="title"
                placeholder="Contoh: Javascript: The Good Parts"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                required
              />
            </div>
          </div>

          {/* Penulis Buku */}
          <div className="col-md-6">
            <label htmlFor="author" className="form-label fw-semibold">
              Penulis (Author) <span className="text-danger">*</span>
            </label>
            <div className="input-group">
              <span className="input-group-text"><i className="bi bi-person"></i></span>
              <input
                type="text"
                className="form-control"
                id="author"
                placeholder="Contoh: Douglas Crockford"
                value={author}
                onChange={(e) => setAuthor(e.target.value)}
                required
              />
            </div>
          </div>

          {/* Tahun Terbit */}
          <div className="col-md-4">
            <label htmlFor="year" className="form-label fw-semibold">
              Tahun Terbit
            </label>
            <div className="input-group">
              <span className="input-group-text"><i className="bi bi-calendar"></i></span>
              <input
                type="number"
                className="form-control"
                id="year"
                placeholder="Contoh: 2023"
                value={year}
                onChange={(e) => setYear(e.target.value)}
                min="1800"
                max="2100"
              />
            </div>
          </div>

          {/* URL Gambar */}
          <div className="col-md-8">
            <label htmlFor="image" className="form-label fw-semibold d-flex justify-content-between">
              <span>URL Gambar Cover</span>
              <button
                type="button"
                className="btn btn-link btn-sm p-0 text-decoration-none"
                onClick={handleUseSampleImage}
              >
                <i className="bi bi-magic me-1"></i>Gunakan Contoh URL
              </button>
            </label>
            <div className="input-group">
              <span className="input-group-text"><i className="bi bi-image"></i></span>
              <input
                type="url"
                className="form-control"
                id="image"
                placeholder="https://images.unsplash.com/..."
                value={image}
                onChange={(e) => setImage(e.target.value)}
              />
            </div>
            <div className="form-text">Biarkan kosong jika ingin menggunakan gambar placeholder default.</div>
          </div>

          {/* Deskripsi */}
          <div className="col-12">
            <label htmlFor="description" className="form-label fw-semibold">
              Deskripsi Singkat
            </label>
            <textarea
              className="form-control"
              id="description"
              rows="3"
              placeholder="Tuliskan ringkasan sinopsis atau isi buku secara singkat..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
            ></textarea>
          </div>

          {/* Tombol Simpan */}
          <div className="col-12 d-flex justify-content-end gap-2 pt-2">
            <button
              type="button"
              className="btn btn-outline-secondary"
              onClick={() => {
                setTitle('');
                setAuthor('');
                setYear('');
                setDescription('');
                setImage('');
                setErrorMessage('');
              }}
            >
              Reset
            </button>
            <button type="submit" className="btn btn-primary px-4">
              <i className="bi bi-plus-circle me-2"></i>
              Simpan Buku
            </button>
          </div>
        </div>
      </form>
    </div>
  );
}
