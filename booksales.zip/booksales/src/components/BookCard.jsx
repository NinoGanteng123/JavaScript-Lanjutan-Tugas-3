import React, { useState } from 'react';

export default function BookCard({ book, onDelete }) {
  const { id, title, author, year, description, image } = book;
  const [imgSrc, setImgSrc] = useState(image);

  // Fallback jika URL gambar bermasalah
  const handleImageError = () => {
    setImgSrc('https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=600&q=80');
  };

  return (
    <div className="card book-card shadow-sm h-100">
      <div className="book-image-wrapper">
        <img
          src={imgSrc}
          alt={title}
          className="book-card-img"
          onError={handleImageError}
          loading="lazy"
        />
        <span className="book-badge-year">
          <i className="bi bi-calendar3 me-1"></i>
          {year}
        </span>
      </div>

      <div className="card-body d-flex flex-column p-3">
        <h5 className="book-title" title={title}>
          {title}
        </h5>

        <div className="book-author">
          <i className="bi bi-person me-1 text-primary"></i>
          {author}
        </div>

        <p className="book-desc" title={description}>
          {description}
        </p>

        <div className="mt-auto pt-2 border-top d-flex justify-content-between align-items-center">
          <span className="badge bg-light text-secondary border">
            ID: #{id}
          </span>
          <div className="d-flex gap-1">
            {onDelete && (
              <button
                type="button"
                className="btn btn-sm btn-outline-danger"
                title="Hapus buku"
                onClick={() => onDelete(id)}
              >
                <i className="bi bi-trash"></i>
              </button>
            )}
            <button
              type="button"
              className="btn btn-sm btn-primary"
              onClick={() => alert(`Anda memilih buku: "${title}" oleh ${author}`)}
            >
              <i className="bi bi-eye me-1"></i>
              Detail
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
