import React from 'react';
import { NavLink, Link } from 'react-router-dom';

export default function Navbar({ bookCount }) {
  return (
    <nav className="navbar navbar-expand-lg navbar-dark bg-dark sticky-top shadow-sm py-3">
      <div className="container">
        {/* Brand Logo */}
        <Link className="navbar-brand d-flex align-items-center gap-2 fw-bold text-white fs-4" to="/">
          <span className="badge bg-primary p-2 rounded">
            <i className="bi bi-book-half"></i>
          </span>
          <span>Book<span className="text-primary">Sales</span></span>
        </Link>

        {/* Toggler mobile */}
        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarContent"
          aria-controls="navbarContent"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon"></span>
        </button>

        {/* Nav Links */}
        <div className="collapse navbar-collapse" id="navbarContent">
          <ul className="navbar-nav me-auto mb-2 mb-lg-0 ms-lg-4 gap-lg-2">
            <li className="nav-item">
              <NavLink
                to="/"
                className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}
                end
              >
                <i className="bi bi-house-door me-1"></i>
                Home
              </NavLink>
            </li>
            <li className="nav-item">
              <NavLink
                to="/books"
                className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}
              >
                <i className="bi bi-collection me-1"></i>
                Book
              </NavLink>
            </li>
            <li className="nav-item">
              <NavLink
                to="/add-book"
                className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}
              >
                <i className="bi bi-plus-square me-1"></i>
                Tambah Buku
              </NavLink>
            </li>
          </ul>

          {/* Quick Counter Badge */}
          <div className="d-flex align-items-center gap-2">
            <Link to="/books" className="btn btn-outline-light btn-sm d-flex align-items-center gap-2">
              <i className="bi bi-bookshelf"></i>
              <span>Total Buku:</span>
              <span className="badge bg-primary">{bookCount}</span>
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
}
