import React from 'react';
import { Link } from 'react-router-dom';

export default function Footer() {
  return (
    <footer className="bg-dark text-secondary py-4 mt-auto border-top border-secondary-subtle">
      <div className="container">
        <div className="row g-4 align-items-center">
          <div className="col-md-6 text-center text-md-start">
            <div className="d-flex align-items-center justify-content-center justify-content-md-start gap-2 mb-2">
              <span className="badge bg-primary p-1">
                <i className="bi bi-book-half"></i>
              </span>
              <span className="fw-bold text-white fs-5">BookSales</span>
            </div>
            <p className="small mb-0 text-secondary">
              Platform Penjualan dan Manajemen Katalog Buku React JS sederhana, bersih, dan terstruktur.
            </p>
          </div>

          <div className="col-md-6 text-center text-md-end">
            <div className="d-flex justify-content-center justify-content-md-end gap-3 mb-2">
              <Link to="/" className="text-secondary text-decoration-none small hover-white">Home</Link>
              <Link to="/books" className="text-secondary text-decoration-none small hover-white">Book</Link>
              <Link to="/add-book" className="text-secondary text-decoration-none small hover-white">Tambah Buku</Link>
            </div>
            <div className="small text-secondary">
              &copy; {new Date().getFullYear()} BookSales. Tugas React JS Lanjutan.
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
