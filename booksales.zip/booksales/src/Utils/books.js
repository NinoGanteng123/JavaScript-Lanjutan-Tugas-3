// src/Utils/books.js
// Data dummy daftar buku untuk aplikasi BookSales

const books = [
  {
    id: 1,
    title: "Clean Code: A Handbook of Agile Software Craftsmanship",
    author: "Robert C. Martin",
    year: 2008,
    description: "Panduan komprehensif mengenai etika rekayasa perangkat lunak, teknik penulisan kode yang rapi, mudah dibaca, serta mudah dipelihara.",
    image: "https://images.unsplash.com/photo-1532012164546-f432f2e3777a?auto=format&fit=crop&w=600&q=80"
  },
  {
    id: 2,
    title: "The Pragmatic Programmer",
    author: "Andrew Hunt & David Thomas",
    year: 2019,
    description: "Buku klasik legendaris yang membahas tips praktis, filosofi pengembang profesional, dan pendekatan pragmatis dalam membangun sistem perangkat lunak modern.",
    image: "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=600&q=80"
  },
  {
    id: 3,
    title: "You Don't Know JS: Scope & Closures",
    author: "Kyle Simpson",
    year: 2020,
    description: "Eksplorasi mendalam mekanisme inti bahasa JavaScript, membedah lexical scope, closure, hoisting, dan cara kerja mesin JavaScript di balik layar.",
    image: "https://images.unsplash.com/photo-1544947950-fa07a98d237f?auto=format&fit=crop&w=600&q=80"
  },
  {
    id: 4,
    title: "Learning React: Modern Patterns for Developing React Apps",
    author: "Alex Banks & Eve Porcello",
    year: 2020,
    description: "Panduan praktis membangun aplikasi web interaktif dengan React modern, meliputi functional components, hooks, state management, dan arsitektur komponen.",
    image: "https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&w=600&q=80"
  },
  {
    id: 5,
    title: "Design Patterns: Elements of Reusable Object-Oriented Software",
    author: "Erich Gamma, Richard Helm, Ralph Johnson, John Vlissides",
    year: 1994,
    description: "Katalog pola desain perangkat lunak berorientasi objek yang paling berpengaruh di industri, menjadi standar solusi problem arsitektur berulang.",
    image: "https://images.unsplash.com/photo-1497633762265-9d179a990aa6?auto=format&fit=crop&w=600&q=80"
  },
  {
    id: 6,
    title: "Refactoring: Improving the Design of Existing Code",
    author: "Martin Fowler",
    year: 2018,
    description: "Strategi teruji untuk merombak struktur internal kode tanpa mengubah perilaku eksternalnya, meningkatkan maintainability dan kualitas kode.",
    image: "https://images.unsplash.com/photo-1589829085413-56de8ae18c73?auto=format&fit=crop&w=600&q=80"
  },
  {
    id: 7,
    title: "Eloquent JavaScript: A Modern Introduction to Programming",
    author: "Marijn Haverbeke",
    year: 2018,
    description: "Pengantar mendalam dan terperinci untuk pemrograman JavaScript modern, web browser, serta Node.js dengan beragam latihan interaktif.",
    image: "https://images.unsplash.com/photo-1543002588-bfa74002ed7e?auto=format&fit=crop&w=600&q=80"
  },
  {
    id: 8,
    title: "Laskar Pelangi",
    author: "Andrea Hirata",
    year: 2005,
    description: "Kisah inspiratif tentang perjuangan sepuluh anak di Belitung dalam menempuh pendidikan di tengah keterbatasan fasilitas dan kehidupan ekonomi.",
    image: "https://images.unsplash.com/photo-1495446815901-a7297e633e8d?auto=format&fit=crop&w=600&q=80"
  },
  {
    id: 9,
    title: "Bumi Manusia",
    author: "Pramoedya Ananta Toer",
    year: 1980,
    description: "Mahakarya sastra Indonesia berlatar era kolonial Hindia Belanda awal abad ke-20, menceritakan kisah Minke dan pergulatan martabat manusia.",
    image: "https://images.unsplash.com/photo-1524995997946-a1c2e315a42f?auto=format&fit=crop&w=600&q=80"
  },
  {
    id: 10,
    title: "Filosofi Teras",
    author: "Henry Manampiring",
    year: 2019,
    description: "Penerapan filsafat Yunani-Romawi Kuno (Stoisisme) ke dalam konteks kekinian untuk mengelola emosi negatif dan menjalani hidup dengan tenang.",
    image: "https://images.unsplash.com/photo-1476275466078-4007374efbbe?auto=format&fit=crop&w=600&q=80"
  }
];

export default books;
