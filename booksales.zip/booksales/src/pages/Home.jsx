import React from 'react';
import { Link } from 'react-router-dom';
import BookCard from '../components/BookCard';

export default function Home({ books, onDeleteBook }) {
  // Ambil buku terbaru atau tampilkan koleksi
  const totalBooks = books.length;
  const latestYear = books.length > 0 ? Math.max(...books.map((b) => Number(b.year) || 0)) : '-';

  return (
    <div className="container py-4">
      {/* Hero Banner Section */}
      <section className="hero-banner shadow-sm text-center text-md-start">
        <div className="row align-items-center g-4">
          <div className="col-lg-8">
            <span className="badge bg-light text-primary fw-semibold px-3 py-2 rounded-pill mb-3">
              <i className="bi bi-stars me-1"></i> Selamat Datang di BookSales
            </span>
            <h1 className="display-5 fw-bold mb-3">
              Jelajahi & Kelola Koleksi Buku Favorit Anda
            </h1>
            <p className="lead mb-4 text-light opacity-90">
              Temukan referensi buku pemrograman terbaik, sastra klasik, dan pengembangan diri. Tambahkan koleksi buku baru dengan mudah dan cepat.
            </p>
            <div className="d-flex flex-wrap gap-2 justify-content-center justify-content-md-start">
              <Link to="/books" className="btn btn-light btn-lg text-primary fw-semibold px-4">
                <i className="bi bi-collection me-2"></i>
                Buka Katalog Lengkap
              </Link>
              <Link to="/add-book" className="btn btn-outline-light btn-lg px-4">
                <i className="bi bi-plus-circle me-2"></i>
                Tambah Buku Baru
              </Link>
            </div>
          </div>

          <div className="col-lg-4 text-center">
            <div className="bg-white text-dark p-4 rounded-4 shadow-sm border text-start">
              <h5 className="fw-bold mb-3 text-primary d-flex align-items-center gap-2">
                <i className="bi bi-bar-chart-fill"></i> Ringkasan Koleksi
              </h5>
              <div className="d-flex justify-content-between py-2 border-bottom">
                <span className="text-muted">Total Buku Tersedia:</span>
                <span className="fw-bold fs-6">{totalBooks} Buku</span>
              </div>
              <div className="d-flex justify-content-between py-2 border-bottom">
                <span className="text-muted">Tahun Terbit Terbaru:</span>
                <span className="fw-bold fs-6">{latestYear}</span>
              </div>
              <div className="d-flex justify-content-between py-2">
                <span className="text-muted">Status Penyimpanan:</span>
                <span className="badge bg-success-subtle text-success">Aktif (State)</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Bagian Daftar Buku (Menggunakan fungsi .map()) */}
      <section className="mb-5">
        <div className="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-2 mb-4 pb-2 border-bottom">
          <div>
            <h3 className="fw-bold mb-1">
              <i className="bi bi-grid-fill text-primary me-2"></i>
              Daftar Koleksi Buku di Halaman Home
            </h3>
            <p className="text-muted mb-0">
              Menampilkan {books.length} buku yang dirender secara dinamis menggunakan fungsi <code>.map()</code>
            </p>
          </div>
          <Link to="/books" className="btn btn-outline-primary btn-sm align-self-start align-self-md-auto">
            Lihat Semua di Halaman Book <i className="bi bi-arrow-right ms-1"></i>
          </Link>
        </div>

        {/* Grid Kartu Buku (Card Layout) */}
        <div className="row g-4">
          {books.map((book) => (
            <div key={book.id} className="col-12 col-sm-6 col-md-4 col-lg-3 d-flex">
              <BookCard book={book} onDelete={onDeleteBook} />
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
