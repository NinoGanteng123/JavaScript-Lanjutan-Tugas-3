import React from 'react';
import { useNavigate } from 'react-router-dom';
import AddBookForm from '../components/AddBookForm';

export default function AddBook({ onAddBook }) {
  const navigate = useNavigate();

  const handleBookAdded = (newBook) => {
    onAddBook(newBook);
    // Beri sedikit jeda atau langsung arahkan ke halaman katalog
    setTimeout(() => {
      navigate('/books');
    }, 1200);
  };

  return (
    <div className="container py-4">
      <div className="row justify-content-center">
        <div className="col-lg-9">
          <div className="mb-4">
            <h2 className="fw-bold mb-1 d-flex align-items-center gap-2">
              <i className="bi bi-pencil-square text-primary"></i>
              Formulir Tambah Buku Baru
            </h2>
            <p className="text-muted mb-0">
              Formulir ini memanfaatkan hook <code>useState</code> untuk mengelola input formulir dan menambahkan data ke dalam daftar buku.
            </p>
          </div>

          <AddBookForm onAddBook={handleBookAdded} />
        </div>
      </div>
    </div>
  );
}
