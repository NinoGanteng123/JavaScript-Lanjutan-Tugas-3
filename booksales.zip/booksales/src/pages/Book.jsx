import React, { useState } from 'react';
import BookCard from '../components/BookCard';
import AddBookForm from '../components/AddBookForm';

export default function Book({ books, onAddBook, onDeleteBook }) {
  // Hook useState untuk pencarian / filter buku
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);

  // Filter buku berdasarkan input pencarian
  const filteredBooks = books.filter((book) => {
    const titleMatch = book.title.toLowerCase().includes(searchTerm.toLowerCase());
    const authorMatch = book.author.toLowerCase().includes(searchTerm.toLowerCase());
    const yearMatch = String(book.year).includes(searchTerm);
    return titleMatch || authorMatch || yearMatch;
  });

  return (
    <div className="container py-4">
      {/* Header Halaman Book */}
      <div className="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4 pb-3 border-bottom">
        <div>
          <h2 className="fw-bold mb-1 d-flex align-items-center gap-2">
            <i className="bi bi-collection-fill text-primary"></i>
            Katalog Buku (Halaman Book)
          </h2>
          <p className="text-muted mb-0">
            Daftar lengkap katalog buku yang di-render secara dinamis menggunakan fungsi <code>.map()</code>
          </p>
        </div>

        {/* Tombol Toggle Form Tambah Buku */}
        <button
          type="button"
          className={`btn ${showAddForm ? 'btn-secondary' : 'btn-primary'} d-flex align-items-center gap-2`}
          onClick={() => setShowAddForm(!showAddForm)}
        >
          <i className={`bi ${showAddForm ? 'bi-x-lg' : 'bi-plus-circle'}`}></i>
          {showAddForm ? 'Tutup Form Tambah' : 'Tambah Buku Baru'}
        </button>
      </div>

      {/* Bagian Form Tambah Buku (Kondisional / Toggle) */}
      {showAddForm && (
        <div className="mb-4">
          <AddBookForm
            onAddBook={(newBook) => {
              onAddBook(newBook);
              setShowAddForm(false);
            }}
          />
        </div>
      )}

      {/* Bar Pencarian */}
      <div className="row g-3 align-items-center mb-4">
        <div className="col-md-6 col-lg-5">
          <div className="input-group">
            <span className="input-group-text bg-white border-end-0">
              <i className="bi bi-search text-muted"></i>
            </span>
            <input
              type="text"
              className="form-control border-start-0 ps-0"
              placeholder="Cari berdasarkan judul, penulis, atau tahun..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            {searchTerm && (
              <button
                className="btn btn-outline-secondary border-start-0"
                type="button"
                onClick={() => setSearchTerm('')}
              >
                <i className="bi bi-x"></i>
              </button>
            )}
          </div>
        </div>

        <div className="col-md-6 col-lg-7 text-md-end">
          <span className="text-muted small">
            Menampilkan <strong>{filteredBooks.length}</strong> dari <strong>{books.length}</strong> total buku
          </span>
        </div>
      </div>

      {/* Grid Kartu Buku (Rendering dengan fungsi .map()) */}
      {filteredBooks.length > 0 ? (
        <div className="row g-4">
          {filteredBooks.map((book) => (
            <div key={book.id} className="col-12 col-sm-6 col-md-4 col-lg-3 d-flex">
              <BookCard book={book} onDelete={onDeleteBook} />
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-5 bg-white rounded-3 border">
          <div className="text-muted mb-3">
            <i className="bi bi-journal-x display-4 text-secondary"></i>
          </div>
          <h5 className="fw-semibold">Tidak ada buku yang cocok dengan pencarian</h5>
          <p className="text-muted small mb-3">Coba gunakan kata kunci lain seperti judul buku atau nama penulis.</p>
          <button
            type="button"
            className="btn btn-outline-primary btn-sm"
            onClick={() => setSearchTerm('')}
          >
            Reset Pencarian
          </button>
        </div>
      )}
    </div>
  );
}
