# BookSales - Toko & Katalog Buku Online

Proyek aplikasi web React JS untuk katalog dan manajemen buku berbasis instruksi tugas.

## 📌 Fitur Utama

1. **Data Buku (`src/Utils/books.js`)**:
   - Memuat 10 data buku lengkap dengan properti: `id`, `title`, `author`, `year`, `description`, dan `image`.
   - Diekspor sebagai default export (`export default books;`).

2. **Komponen & Navigasi**:
   - Menggunakan fungsi `.map()` untuk merender daftar buku secara dinamis di halaman **Home** (`/`) dan halaman **Book** (`/books` & `/book`).
   - Layout kartu (*card*) sederhana, bersih, dan rapi untuk menampilkan detail setiap buku.
   - Dilengkapi navigasi responsif dengan React Router DOM (`NavLink`, `Routes`, `Route`).

3. **Fitur Tambahan (Hooks)**:
   - Form penambahan buku menggunakan React Hook `useState` untuk mengelola input formulir secara terkontrol (*controlled components*).
   - Buku yang ditambahkan langsung tersimpan ke dalam state aplikasi dan tampil seketika di halaman Home maupun Book.
   - Dilengkapi tombol cepat "Gunakan Contoh URL" serta fitur pencarian/filter buku di halaman Book.

4. **Desain & Tampilan**:
   - Tampilan bersih, rapi, modern, dan presisi menggunakan Bootstrap 5 dan CSS Grid/Flexbox tanpa animasi yang rumit.

---

## 📂 Struktur Direktori Proyek

```text
booksales/
├── public/
├── src/
│   ├── Utils/
│   │   └── books.js              # Array data buku awal (default export)
│   ├── components/
│   │   ├── AddBookForm.jsx       # Formulir input buku baru (useState)
│   │   ├── BookCard.jsx          # Komponen kartu detail buku
│   │   ├── Footer.jsx            # Komponen footer halaman
│   │   └── Navbar.jsx            # Komponen navigasi header
│   ├── pages/
│   │   ├── AddBook.jsx           # Halaman tersendiri untuk formulir tambah buku
│   │   ├── Book.jsx              # Halaman Book (.map() + pencarian)
│   │   └── Home.jsx              # Halaman Home (.map() + hero banner)
│   ├── App.jsx                   # Root component & state management
│   ├── index.css                 # Custom CSS & layout styling
│   └── main.jsx                  # Entry point React
├── index.html                    # Template HTML utama + Bootstrap 5 CDN
├── package.json                  # Konfigurasi dependensi proyek
└── vite.config.js                # Konfigurasi build tool Vite
```

---

## 🚀 Cara Menjalankan Proyek

1. **Pastikan Node.js sudah terinstal**, lalu buka terminal di folder proyek `booksales`:
   ```bash
   cd booksales
   ```

2. **Instal dependensi** (jika belum):
   ```bash
   npm install
   ```

3. **Jalankan development server**:
   ```bash
   npm run dev
   ```

4. Buka tautan lokal yang ditampilkan di terminal (biasanya `http://localhost:5173`) di browser Anda.
